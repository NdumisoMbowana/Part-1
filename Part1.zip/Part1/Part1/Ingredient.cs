﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part1
{
    internal class Ingredient
    {

        public string Name { get; set; }

        public double Quantity { get; set; }

        public string Unit { get; set; }

    }



    class Step

    {

        public int Number { get; set; }

        public string Description { get; set; }

    }



    class Recipe

    {

        public List<Ingredient> Ingredients { get; set; }

        public List<Step> Steps { get; set; }



        public Recipe()

        {

            Ingredients = new List<Ingredient>();

            Steps = new List<Step>();

        }



        public void Display()

        {

            Console.WriteLine("Recipe:");

            Console.WriteLine("Ingredients:");

            foreach (var ingredient in Ingredients)

            {

                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");

            }

            Console.WriteLine("Steps:");

            foreach (var step in Steps)

            {

                Console.WriteLine($"{step.Number}. {step.Description}");

            }

        }



        public void Scale(double factor)

        {

            foreach (var ingredient in Ingredients)

            {

                ingredient.Quantity *= factor;

            }

        }



        public void ResetQuantities(List<Ingredient> originalIngredients)

        {

            for (int i = 0; i < Ingredients.Count; i++)

            {

                Ingredients[i].Quantity = originalIngredients[i].Quantity;

            }

        }



        public void Clear()

        {

            Ingredients.Clear();

            Steps.Clear();

        }
    }
}






    