﻿using Part1;

public class Program
{
   
    static void Main(string[] args)
    {
        

        {

            Console.WriteLine("Welcome to the Recipe App!");



            Recipe recipe = null;

            List<Ingredient> originalIngredients = new List<Ingredient>();



            while (true)

            {

                Console.WriteLine("\nMenu:");

                Console.WriteLine("1. Enter a new recipe");

                Console.WriteLine("2. View the recipe details");

                Console.WriteLine("3. Adjust the recipe scale");

                Console.WriteLine("4. Reset ingredient quantities to original values");

                Console.WriteLine("5. Clear entered recipe data");

                Console.WriteLine("6. Exit the application");

                Console.Write("Please choose an option: ");

                int choice;

                while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 6)

                {

                    Console.Write("Invalid input. Please enter a number between 1 and 6: ");

                }



                switch (choice)

                {

                    case 1:

                        recipe = EnterRecipe();

                        originalIngredients = new List<Ingredient>(recipe.Ingredients); // Store original ingredients for reset

                        break;

                    case 2:

                        if (recipe == null)

                        {

                            Console.WriteLine("No recipe entered yet.");

                        }

                        else

                        {

                            Console.WriteLine("\nRecipe Details:");

                            recipe.Display();

                        }

                        break;

                    case 3:

                        if (recipe == null)

                        {

                            Console.WriteLine("Please enter a recipe first.");

                        }

                        else

                        {

                            Console.Write("\nEnter the scaling factor (0.5, 2, or 3): ");

                            double factor;

                            while (!double.TryParse(Console.ReadLine(), out factor) || (factor != 0.5 && factor != 2 && factor != 3))

                            {

                                Console.Write("Invalid input. Please enter 0.5, 2, or 3: ");

                            }

                            recipe.Scale(factor);

                            Console.WriteLine("Recipe scaled successfully.");

                        }

                        break;

                    case 4:

                        if (recipe == null)

                        {

                            Console.WriteLine("No recipe entered yet.");

                        }

                        else

                        {

                            recipe.ResetQuantities(originalIngredients);

                            Console.WriteLine("Ingredient quantities reset to their original values.");

                        }

                        break;

                    case 5:

                        if (recipe == null)

                        {

                            Console.WriteLine("No data to clear.");

                        }

                        else

                        {

                            recipe.Clear();

                            Console.WriteLine("Entered recipe data cleared.");

                        }

                        break;

                    case 6:

                        Console.WriteLine("Exiting the application...");

                        return;

                }

            }

        }



        static Recipe EnterRecipe()

        {

            Console.WriteLine("\nEnter Recipe Details:");



            Console.Write("Enter the number of ingredients: ");

            int numIngredients = int.Parse(Console.ReadLine());



            Console.Write("Enter the number of steps: ");

            int numSteps = int.Parse(Console.ReadLine());



            Recipe recipe = new Recipe();



            for (int i = 0; i < numIngredients; i++)

            {

                Console.WriteLine($"\nIngredient {i + 1}:");

                Console.Write("Name: ");

                string name = Console.ReadLine();



                Console.Write("Quantity: ");

                double quantity = double.Parse(Console.ReadLine());



                Console.Write("Unit of measurement: ");

                string unit = Console.ReadLine();



                recipe.Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Unit = unit });

            }



            for (int i = 0; i < numSteps; i++)

            {

                Console.WriteLine($"\nStep {i + 1}:");

                Console.Write("Description: ");

                string description = Console.ReadLine();



                recipe.Steps.Add(new Step { Number = i + 1, Description = description });

            }



            return recipe;

        }

    
    }
}

    